document.addEventListener("DOMContentLoaded", startTHREE);

function startTHREE()
{
    // your code here
}