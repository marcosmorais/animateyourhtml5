document.addEventListener("DOMContentLoaded", function() {

// ---------------------your code here-------------------------

//           ___________  __,__
//     ----- | ||| |||| | | |__|
//      ---- | ._    _. |_|code|
//       --- `-(o)--(o)----(o)-'

});